#!/usr/bin/env python3
"""
consolidate_eventstore.py  (v3)
============================================================
Builds and pushes the two DAILY eventstore uploads from a day's
Shadowserver pull.

  1. ioc_blocklist   <- blocklist-*.csv, as-is (copied through)
  2. asset_exposure  <- device_id-*.csv + every scan_*-*.csv, trimmed
                        to a CORE schema + an added `service` column

WHY "TRIMMED" NOW, NOT A FULL COLUMN UNION
  Inspecting the actual files (reports.zip) showed every scan_* type
  shares the same 14-column core:
    timestamp, severity, ip, protocol, port, hostname, tag, asn,
    geo, region, city, naics, hostname_source, sector
  ...and then diverges hard. scan_ssh adds ~80 columns of raw key/
  cipher material, scan_ssl adds ~70 columns of full certificate
  chains, etc. Unioning all of that (the v2 approach) would produce
  a ~200-column, mostly-empty-per-row file, and the protocol-specific
  fields are single-scan forensic detail that's stale the moment the
  next day's scan replaces it -- nothing joins a detection rule
  against an SSH host key. That's the "outdated data that isn't
  necessary" case you flagged.

  So asset_exposure now keeps only:
    CORE fields (the 14 above) + device_vendor/device_type/
    device_model/device_version (kept when the source file has them,
    blank otherwise -- device_id and some scan types carry these,
    most don't) + `service` (derived from the filename).

  If a specific investigation later needs the deep protocol fields
  for one scan type (e.g. SSL cert expiry for a vuln-management use
  case), that's a deliberate, separate, single-purpose eventstore --
  not something to fold into the general-purpose exposure lookup.

REPLACE, NOT APPEND -- CONFIRMED
  DNIF rejects uploading to a store name that already exists, so
  each run now does delete-then-upload (see dnif_client.py's
  replace_and_upload, wired from your delete API capture). This is
  what guarantees the eventstore never carries yesterday's rows
  forward -- every run is a clean full replace.

RUN (cron, right after report-manager.py finishes)
  15 6 * * * /usr/bin/python3 /opt/shadowserver/consolidate_eventstore.py
============================================================
"""

import csv
import os
import re
import sys
from datetime import datetime, timezone


def utcnow() -> datetime:
    """datetime.utcnow() is deprecated (Python 3.12+) -- kept naive so
    it drops into the existing date-arg parsing/comparisons unchanged."""
    return datetime.now(timezone.utc).replace(tzinfo=None)
from pathlib import Path

from dnif_client import DnifClient
from credentials import load_credentials, require
import diff_compromised_website

REPORTS_ROOT = Path("/DNIF/SHADOWSERVER_API_INTEGRATION/tool/reports")
OUTPUT_DIR = Path("/DNIF/SHADOWSERVER_API_INTEGRATION/eventstore_uploads")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# ---- DNIF console config -- CONFIRM these against production -----
DNIF_HOST = "10.90.9.159"                              # CONFIRM vs 172.16.85.209
DNIF_TENANT = None  # auto-discovered from login response -- see dnif_client.py.
                     # Set explicitly only if this account has access to more
                     # than one cluster and you need a specific one.
_creds = load_credentials()
require(_creds, "DNIF_EMAIL", "DNIF_PASSWORD")
DNIF_EMAIL = _creds["DNIF_EMAIL"]
DNIF_PASSWORD = _creds["DNIF_PASSWORD"]
DNIF_SCOPE_ID = "scope-01-pomdc"

# Confirmed common core across every scan_*/device_id file inspected.
CORE_FIELDS = [
    "timestamp", "severity", "ip", "protocol", "port", "hostname",
    "tag", "asn", "geo", "region", "city", "naics", "hostname_source",
    "sector",
]
DEVICE_FIELDS = ["device_vendor", "device_type", "device_model", "device_version"]

# scan_ftp (confirmed against real sample data) doesn't have a `sector`
# column at all -- it carries the same value under `device_sector`
# instead. Rather than skip the whole file (and lose every FTP exposure
# row), fall back to this alias when `sector` itself isn't present.
SECTOR_ALIASES = ["sector", "device_sector"]

# Filename pattern: 2026-07-26-scan_ssh-11993-png_dataco-asn.csv
FNAME_RE = re.compile(r"^\d{4}-\d{2}-\d{2}-(?P<type>[a-z0-9_]+)-\d+-.+\.csv$")


def report_date_dir(date: datetime) -> Path:
    return REPORTS_ROOT / f"{date.year:04d}" / f"{date.month:02d}" / f"{date.day:02d}"


def find_files(date_dir: Path, prefix_predicate):
    if not date_dir.exists():
        return []
    out = []
    for f in sorted(date_dir.glob("*.csv")):
        m = FNAME_RE.match(f.name)
        if not m:
            continue
        if prefix_predicate(m.group("type")):
            out.append((m.group("type"), f))
    return out


def build_blocklist(date_dir: Path, out_path: Path) -> bool:
    files = find_files(date_dir, lambda t: t == "blocklist")
    if not files:
        print("  no blocklist file found, skipping")
        return False
    _, src = files[0]
    out_path.write_bytes(src.read_bytes())
    print(f"  wrote {out_path}")
    return True


def build_compromised_assets(date_dir: Path, out_path: Path) -> bool:
    """
    Full daily snapshot, as-is -- same treatment as blocklist. Volume
    is small (single digits/day in the sample data), so no column
    trimming needed here; every field is worth keeping for this one.
    The day-over-day NEW-entry alerting is a separate concern, handled
    by diff_compromised_website.py, not this function.
    """
    files = find_files(date_dir, lambda t: t == "compromised_website")
    if not files:
        print("  no compromised_website file found, skipping")
        return False
    _, src = files[0]
    out_path.write_bytes(src.read_bytes())
    print(f"  wrote {out_path}")
    return True


def build_asset_exposure(date_dir: Path, out_path: Path) -> bool:
    files = find_files(date_dir, lambda t: t == "device_id" or t.startswith("scan_"))
    if not files:
        print("  no device_id/scan_* files found, skipping")
        return False

    out_fields = CORE_FIELDS + DEVICE_FIELDS + ["service"]

    with open(out_path, "w", newline="", encoding="utf-8") as fout:
        writer = csv.DictWriter(fout, fieldnames=out_fields, restval="")
        writer.writeheader()
        total = 0
        skipped_missing_core = 0
        for report_type, path in files:
            service_name = (
                report_type[len("scan_"):] if report_type.startswith("scan_") else report_type
            )
            with open(path, newline="", encoding="utf-8") as f:
                reader = csv.DictReader(f)
                available = set(reader.fieldnames or [])

                # `sector` has a known alias (`device_sector`, seen in
                # scan_ftp) -- resolve which column name this file
                # actually uses before checking for missing core columns.
                sector_col = next((c for c in SECTOR_ALIASES if c in available), None)
                required_core = [c for c in CORE_FIELDS if c != "sector"]
                missing_core = [c for c in required_core if c not in available]
                if sector_col is None:
                    missing_core.append("sector (or device_sector)")

                if missing_core:
                    # Don't silently drop a whole report type -- flag it so
                    # it gets investigated instead of quietly losing data.
                    print(f"  WARNING: {path.name} is missing core columns "
                          f"{missing_core} -- skipping this file")
                    skipped_missing_core += 1
                    continue

                for row in reader:
                    out_row = {c: row.get(c, "") for c in CORE_FIELDS}
                    out_row["sector"] = row.get(sector_col, "")
                    for c in DEVICE_FIELDS:
                        out_row[c] = row.get(c, "")
                    out_row["service"] = service_name
                    writer.writerow(out_row)
                    total += 1

    print(f"  wrote {out_path} ({total} rows from {len(files)} source files, "
          f"{skipped_missing_core} file(s) skipped for missing core columns)")
    return True


def main():
    date = utcnow()
    if len(sys.argv) > 1:
        date = datetime.strptime(sys.argv[1], "%Y-%m-%d")

    date_dir = report_date_dir(date)
    print(f"processing {date_dir}")

    to_upload = []

    blocklist_out = OUTPUT_DIR / f"ioc_blocklist_{date:%Y%m%d}.csv"
    if build_blocklist(date_dir, blocklist_out):
        to_upload.append((blocklist_out, "ioc_blocklist"))

    exposure_out = OUTPUT_DIR / f"asset_exposure_{date:%Y%m%d}.csv"
    if build_asset_exposure(date_dir, exposure_out):
        to_upload.append((exposure_out, "asset_exposure"))

    compromised_out = OUTPUT_DIR / f"compromised_assets_{date:%Y%m%d}.csv"
    if build_compromised_assets(date_dir, compromised_out):
        to_upload.append((compromised_out, "compromised_assets"))

    if to_upload:
        client = DnifClient(
            host=DNIF_HOST,
            tenant=DNIF_TENANT,
            auth_method="login",
            email=DNIF_EMAIL,
            password=DNIF_PASSWORD,
        )
        for csv_path, store_name in to_upload:
            print(f"  uploading {csv_path.name} -> eventstore '{store_name}' (replace) ...")
            result = client.replace_and_upload(
                csv_path.as_posix(), store_name, scope_id=DNIF_SCOPE_ID
            )
            print(f"  done: {result}")
    else:
        print("nothing to upload today")

    # Separate concern from the eventstore replace above: figure out
    # which compromised_website rows are genuinely new (vs. the local
    # state file) and forward ONLY those to the stream as real events.
    # This computation is entirely local -- see diff_compromised_website.py.
    print("checking for newly-compromised assets...")
    diff_compromised_website.run(date)


if __name__ == "__main__":
    main()
