#!/usr/bin/env python3
"""
credentials.py
============================================================
Loads secrets from a hidden dotfile instead of requiring them typed
into `export` commands (which land in shell history) every time.

DEFAULT LOCATION
  /opt/shadowserver/.shadowserver.api

  Override with the CREDENTIALS_FILE environment variable if you want
  it somewhere else (e.g. a path managed by a secrets tool that drops
  a file on disk).

FORMAT -- simple KEY=VALUE, one per line, like a .env file
  # lines starting with # are comments, blank lines are ignored
  DNIF_EMAIL=himanshu.mehra@dnif.it
  DNIF_PASSWORD=correct-horse-battery-staple

  One file, not one per script -- if this ever needs to also hold
  Shadowserver's own API_KEY/SECRET (the ones shadowserver_relay.py
  originally used) or anything else this pipeline needs, just add
  more KEY=VALUE lines; nothing about the loader is DNIF-specific.

PRECEDENCE
  An already-set environment variable of the same name WINS over
  whatever is in the file. That's deliberate -- it means you can
  still override one value ad hoc (e.g. testing against a different
  account) without editing the file, while the file remains the
  normal day-to-day source of truth for cron runs.

PERMISSIONS
  This file holds plaintext secrets. On load, this warns loudly (does
  NOT refuse to run -- your call whether that should be a hard stop)
  if the file is readable/writable by anyone other than its owner.
  Fix with: chmod 600 /opt/shadowserver/.shadowserver.api

USAGE
  from credentials import load_credentials
  creds = load_credentials()
  email = creds.get("DNIF_EMAIL")
============================================================
"""

import os
import stat
from pathlib import Path

DEFAULT_CREDENTIALS_FILE = Path("/DNIF/SHADOWSERVER_API_INTEGRATION/tool/.shadowserver.api")


def _check_permissions(path: Path):
    mode = path.stat().st_mode
    # Anything in the group/other bits (readable OR writable by
    # non-owner) is worth a loud warning -- this file holds plaintext
    # secrets.
    if mode & (stat.S_IRWXG | stat.S_IRWXO):
        print(f"  WARNING: {path} is readable/writable by group or other "
              f"(mode {oct(mode)[-3:]}). Recommend: chmod 600 {path}")


def load_credentials(path: Path = None) -> dict:
    """
    Returns a dict of every KEY=VALUE line found in the credentials
    file, with any already-set environment variable of the same name
    taking precedence over the file's value.

    Missing file is NOT an error here -- callers decide whether a
    specific key being absent (from both file and environment) is
    fatal for what they need. This just returns whatever it found.
    """
    if path is None:
        path = Path(os.environ.get("CREDENTIALS_FILE", DEFAULT_CREDENTIALS_FILE))

    creds = {}

    if path.exists():
        _check_permissions(path)
        with open(path) as f:
            for lineno, raw_line in enumerate(f, start=1):
                line = raw_line.strip()
                if not line or line.startswith("#"):
                    continue
                if "=" not in line:
                    print(f"  WARNING: {path}:{lineno} doesn't look like KEY=VALUE, skipping: {line!r}")
                    continue
                key, _, value = line.partition("=")
                creds[key.strip()] = value.strip()
    else:
        print(f"  no credentials file at {path} -- relying on environment variables only")

    # Environment variables override the file, not the other way round.
    for key in list(creds.keys()):
        if key in os.environ:
            creds[key] = os.environ[key]

    return creds


def require(creds: dict, *keys):
    """Fail loudly and specifically if any of `keys` is missing/empty,
    naming exactly which ones and where to set them -- rather than a
    generic KeyError three calls later."""
    missing = [k for k in keys if not creds.get(k)]
    if missing:
        raise SystemExit(
            f"Missing required credential(s): {', '.join(missing)}\n"
            f"Set them either in {DEFAULT_CREDENTIALS_FILE} (KEY=VALUE per line) "
            f"or as environment variables."
        )
