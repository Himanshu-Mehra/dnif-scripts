create a file .shadowserver.api in home directory:

vim /DNIF/SHADOWSERVER_API_INTEGRATION/tool/.shadowserver.api

[api]
key = 3b8741b3-2cd7-4215-9c5e-ab43611bed0e
secret = dEADO3KMcW
uri = https://transform.shadowserver.org/api2/

create a file 'config.ini':

[reports]
directory = /DNIF/SHADOWSERVER_API_INTEGRATION/tool/reports
min_disk_free = 512
notifier = none
url_prefix = http://transform.shadowserver.org/api2/

Usage: report-manager.py /path/to/config.ini [ days ]

$ python3 report-manager.py config.ini

