#crontab line

0 12 * * * /usr/bin/python3 /DNIF/SHADOWSERVER_API_INTEGRATION/run_pipeline.py >> /DNIF/SHADOWSERVER_API_INTEGRATION/logs/cron.log 2>&1