#!/usr/bin/env python3
"""
forward_stream_csv.py
============================================================
Forwards the true "event" reports -- event4_sinkhole,
event4_sinkhole_dns, event4_sinkhole_http -- into DNIF as real
timestamped events over TCP: one JSON object per CSV row, using the
CSV HEADER ROW as the JSON keys (e.g. a row with columns
ip,port,tag,timestamp becomes {"ip": ..., "port": ..., "tag": ...,
"timestamp": ...}). A source file is deleted ONLY after every row in
it has been sent successfully -- if any row fails, the whole file is
left in place so the next run retries it.

compromised_website is handled separately by
diff_compromised_website.py -- its rows are state-shaped (same core
schema as scan_*/device_id: ip/port/tag/asn/geo, no src/dst session),
not event-shaped, so the full daily snapshot goes to a
`compromised_assets` eventstore instead, and only the day-over-day
NEW entries get sent to the stream as real events.

TWO THINGS TO CONFIRM BEFORE YOU RUN THIS FOR REAL

  1. FRAMING ON PORT 515 -- this currently sends bare newline-
     delimited JSON over a plain TCP socket. If DNIF's listener on
     515 actually expects syslog framing (an RFC 3164/5424 header
     in front of each message, or RFC 6587 octet-counting) rather
     than raw JSON lines, tell me the exact expected format and
     I'll change send_rows() to match it. Sending the wrong framing
     is the single most common reason a "successful" TCP send still
     shows up as nothing (or garbage) in the SIEM.

  2. WHAT COUNTS AS "CONFIRMATION" -- a plain socket.sendall()
     succeeding only proves the bytes left this host; it is NOT an
     application-level acknowledgment that DNIF actually parsed and
     stored the event. If DNIF's port 515 listener sends back any
     kind of ack/response, tell me its shape and I'll make file
     deletion wait on that instead of just the socket send
     succeeding -- that's the safer contract to delete against.

RUN (cron, after report-manager.py, before cleanup_reports.py)
  20 6 * * * /usr/bin/python3 /opt/shadowserver/forward_stream_csv.py
============================================================
"""

import csv
import os
import re
import sys
from pathlib import Path
from datetime import datetime, timezone


def utcnow() -> datetime:
    """datetime.utcnow() is deprecated (Python 3.12+) -- kept naive so
    it drops into the existing date-arg parsing/comparisons unchanged."""
    return datetime.now(timezone.utc).replace(tzinfo=None)


from stream_forward import send_rows_to_siem

REPORTS_ROOT = Path("/DNIF/SHADOWSERVER_API_INTEGRATION/tool/reports")
SIEM_HOST = os.environ.get("DNIF_SIEM_HOST", "10.90.9.160")  # CONFIRM: real DNIF ingest host
SIEM_PORT = int(os.environ.get("DNIF_SIEM_PORT", "515"))

STREAM_TYPES = {
    "event4_sinkhole",
    "event4_sinkhole_dns",
    "event4_sinkhole_http",
}
# compromised_website is intentionally NOT in this set anymore.
# It's state-shaped data (same core schema as scan_*/device_id), not
# an event -- see diff_compromised_website.py, which sends only the
# day-over-day NEW entries as stream events and pushes the full
# snapshot to the compromised_assets eventstore separately.

FNAME_RE = re.compile(r"^\d{4}-\d{2}-\d{2}-(?P<type>[a-z0-9_]+)-\d+-.+\.csv$")


def report_date_dir(date: datetime) -> Path:
    return REPORTS_ROOT / f"{date.year:04d}" / f"{date.month:02d}" / f"{date.day:02d}"


def forward_file(path: Path, report_type: str) -> bool:
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)  # header row -> JSON keys
        rows = list(reader)

    if not rows:
        print(f"  {path.name}: 0 rows, nothing to send, removing")
        path.unlink()
        return True

    try:
        sent = send_rows_to_siem(SIEM_HOST, SIEM_PORT, rows, report_type)
    except OSError as e:
        print(f"  {path.name}: FAILED to send ({e}) -- file kept, will retry next run")
        return False

    if sent != len(rows):
        print(f"  {path.name}: sent {sent}/{len(rows)} rows -- file kept, will retry next run")
        return False

    print(f"  {path.name}: sent {sent} rows -- removing")
    path.unlink()
    return True


def main():
    date = utcnow()
    if len(sys.argv) > 1:
        date = datetime.strptime(sys.argv[1], "%Y-%m-%d")

    date_dir = report_date_dir(date)
    if not date_dir.exists():
        print(f"no report dir for {date:%Y-%m-%d}, nothing to do")
        return

    for f in sorted(date_dir.glob("*.csv")):
        m = FNAME_RE.match(f.name)
        if not m or m.group("type") not in STREAM_TYPES:
            continue
        print(f"forwarding {f.name}")
        forward_file(f, m.group("type"))


if __name__ == "__main__":
    main()
