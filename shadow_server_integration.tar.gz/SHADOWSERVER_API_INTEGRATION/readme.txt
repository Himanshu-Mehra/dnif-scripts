#crontab line

0 12 * * * /usr/bin/python3 /opt/shadowserver/run_pipeline.py >> /opt/shadowserver/logs/cron.log 2>&1