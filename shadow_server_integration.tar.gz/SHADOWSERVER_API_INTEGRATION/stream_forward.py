#!/usr/bin/env python3
"""
stream_forward.py
============================================================
One shared function for sending CSV-derived rows to DNIF as
newline-delimited JSON over TCP. Used by:
  - forward_stream_csv.py       (sinkhole* files, full daily send)
  - consolidate_eventstore_v3.py (compromised_website, NEW rows only)

Kept as its own module so the framing/connection logic lives in
exactly one place -- if DNIF's port 515 listener turns out to need
syslog framing instead of bare JSON lines (see the open question in
forward_stream_csv.py), it only needs fixing here.
============================================================
"""

import json
import socket


def send_rows_to_siem(host, port, rows, report_type, timeout=15):
    """
    Send `rows` (list of dicts) to host:port as newline-delimited JSON,
    one object per row, each tagged with `report_type`.

    Returns the number of rows sent. Raises OSError on a connection/
    send failure -- callers should treat a raised exception as "nothing
    in this batch is confirmed delivered" and NOT mark the batch as
    processed (don't delete source files, don't update dedup state)
    until this returns successfully.
    """
    if not rows:
        return 0
    sent = 0
    with socket.create_connection((host, port), timeout=timeout) as sock:
        for row in rows:
            row = dict(row)
            row["shadowserver_report_type"] = report_type
            line = json.dumps(row, separators=(",", ":")) + "\n"
            sock.sendall(line.encode("utf-8"))
            sent += 1
    return sent
