#!/usr/bin/env python3
"""
dnif_client.py
============================================================
Shared DNIF console API client. SSID auth via Redis uses the exact
same pattern as dnif_audit2.py. The eventstore methods below were
reverse-engineered from your captured browser traffic:

  POST /api/event_store/list    -> list existing eventstores
  POST /api/event_store/upload  -> multipart (scope_id, name, file),
                                    returns a dispatcher task id
  GET  /wrk/api/dispatcher/task/state/<task_id>
                                 -> poll until task_state == "SUCCESS"

UPLOAD IS ASYNC. The /upload call only confirms DNIF accepted the
file and queued a job:
    {"message": "Event store uploaded", "data": ["<task_id>"]}
That does NOT mean the store is populated yet. Your captures show
the dispatcher task going STARTED/EXECUTING -> SUCCESS/EXECUTED --
you have to poll task/state and see SUCCESS before it's safe to
assume the eventstore has the new data (e.g. before triggering
anything downstream that depends on it, or before deleting the
source CSV).

ONE THING IN YOUR CAPTURES I CAN'T FULLY EXPLAIN: one request
returned {"status":"failed","message":"Invalid store name"} before a
later successful attempt with the SAME name ("TESTINGEVT") went
through and the store then appeared in event_store/list. That points
to either a transient issue, or a validation rule on `name` (e.g. no
spaces/special characters) that the retry happened to satisfy -- I
don't have the failed request's exact payload to pin down which. This
client surfaces that failure message as-is rather than guessing a
rule to enforce client-side. If you hit it again, capture that
specific failing request's payload/headers and I'll nail down the
actual constraint and validate for it before upload.
============================================================
"""

import base64
import subprocess
import sys
import time

import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class DnifClient:
    def __init__(self, host, tenant, redis_container="console-v9",
                 redis_password_b64=None, verify_ssl=False):
        self.base_url = f"https://{host}/{tenant}"
        self.verify_ssl = verify_ssl
        self.redis_container = redis_container
        self.redis_password_b64 = redis_password_b64
        self.ssid = self._get_ssid()
        self.headers = {
            "accept": "application/json",
            "ssid": self.ssid,
        }

    def _get_ssid(self):
        result = subprocess.run(
            ["docker", "ps", "--format", "{{.Names}}"],
            capture_output=True, text=True,
        )
        if self.redis_container not in result.stdout.splitlines():
            sys.exit(f"Docker container {self.redis_container} not running")

        redis_password = base64.b64decode(self.redis_password_b64).decode("utf-8")
        redis_cmd = (
            f"redis-cli -a '{redis_password}' -p 6379 "
            f"--scan --pattern 'ssid:*' 2>/dev/null"
        )
        result = subprocess.run(
            ["docker", "exec", self.redis_container, "sh", "-c", redis_cmd],
            capture_output=True, text=True,
        )
        ssid_lines = [l for l in result.stdout.splitlines() if l.startswith("ssid:")]
        if not ssid_lines:
            sys.exit("Could not fetch SSID from Redis")
        return ssid_lines[-1].split(":", 1)[1]

    def eventstore_list(self, scope_id="default", pageno=1, pagesize=100):
        resp = requests.post(
            f"{self.base_url}/api/event_store/list",
            headers={**self.headers, "content-type": "application/json"},
            json={"pageno": pageno, "pagesize": pagesize, "scope_id": scope_id},
            verify=self.verify_ssl,
            timeout=30,
        )
        resp.raise_for_status()
        return resp.json()

    def eventstore_exists(self, name, scope_id="default"):
        data = self.eventstore_list(scope_id=scope_id, pagesize=1000)
        return any(row.get("name") == name for row in data.get("data", []))

    def eventstore_delete(self, store_name, scope_id="default"):
        """
        POST /api/event_store/delete -- confirmed via captured traffic.
        Payload: {"scope_id": ..., "name": ...}
        Response on success: {"status":"success","data":"Delete event
        store Successfully"}. Only call this when the store is known
        to exist (see eventstore_exists) -- behavior when it doesn't
        exist wasn't captured, so this doesn't guess at it.
        """
        resp = requests.post(
            f"{self.base_url}/api/event_store/delete",
            headers={**self.headers, "content-type": "application/json"},
            json={"scope_id": scope_id, "name": store_name},
            verify=self.verify_ssl,
            timeout=30,
        )
        resp.raise_for_status()
        body = resp.json()
        if body.get("status") != "success":
            raise RuntimeError(f"eventstore delete failed: {body}")
        return body

    def eventstore_upload(self, csv_path, store_name, scope_id="default"):

        """POST the multipart upload. Returns the dispatcher task id."""
        with open(csv_path, "rb") as f:
            resp = requests.post(
                f"{self.base_url}/api/event_store/upload",
                headers=self.headers,  # let requests set multipart content-type/boundary
                data={"scope_id": scope_id, "name": store_name},
                files={"file": (csv_path.split("/")[-1], f, "application/csv")},
                verify=self.verify_ssl,
                timeout=60,
            )
        resp.raise_for_status()
        body = resp.json()
        if body.get("status") != "success":
            raise RuntimeError(f"eventstore upload rejected: {body}")
        return body["data"][0]  # task id, e.g. "5479fbbf-2d24-4fcc-90e3-e64e44e91b28-id-1"

    def wait_for_task(self, task_id, poll_interval=2, timeout=120):
        deadline = time.time() + timeout
        while time.time() < deadline:
            resp = requests.get(
                f"{self.base_url}/wrk/api/dispatcher/task/state/{task_id}",
                headers=self.headers,
                verify=self.verify_ssl,
                timeout=30,
            )
            resp.raise_for_status()
            body = resp.json()
            state = body.get("task_state")
            if state == "SUCCESS":
                return body
            if state in ("FAILURE", "FAILED", "ERROR"):
                raise RuntimeError(f"eventstore task {task_id} failed: {body}")
            time.sleep(poll_interval)
        raise TimeoutError(f"eventstore task {task_id} did not finish within {timeout}s")

    def upload_and_wait(self, csv_path, store_name, scope_id="default"):
        """Upload a CSV and block until DNIF finishes processing it."""
        task_id = self.eventstore_upload(csv_path, store_name, scope_id=scope_id)
        return self.wait_for_task(task_id)

    def replace_and_upload(self, csv_path, store_name, scope_id="default"):
        """
        Delete-then-upload. DNIF rejects re-uploading to a store name
        that already exists, so a daily refresh has to clear the old
        store first, then upload fresh -- this is what makes sure no
        stale IOC/exposure rows linger past their refresh cycle.
        """
        if self.eventstore_exists(store_name, scope_id=scope_id):
            print(f"  '{store_name}' already exists -- deleting before re-upload")
            self.eventstore_delete(store_name, scope_id=scope_id)
        return self.upload_and_wait(csv_path, store_name, scope_id=scope_id)

