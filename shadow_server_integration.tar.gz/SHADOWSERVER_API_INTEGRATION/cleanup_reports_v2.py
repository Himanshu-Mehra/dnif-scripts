#!/usr/bin/env python3
"""
cleanup_reports.py  (v2)
============================================================
Purges old files across every directory this pipeline writes to, so
nothing accumulates on disk unbounded. Three targets, each with its
own retention:

  reports/YYYY/MM/DD/*.csv        <- raw Shadowserver pull       (7 days)
  eventstore_uploads/*.csv        <- consolidated CSVs actually
                                      uploaded to DNIF             (7 days)
  logs/pipeline_*.log             <- run_pipeline.py run logs    (30 days)

WHY 7 / 7 / 30
  reports/ and eventstore_uploads/ are both just staging for daily
  uploads that fully REPLACE the prior day's eventstore -- there's no
  ongoing use for either past the retry window (7 days covers "did
  yesterday's run fail, let me rerun it"). Logs are cheap (tiny text
  files) and useful for longer troubleshooting/audit, so they get a
  longer runway.

FILENAME-BASED, NOT FILE METADATA
  v1 of this script used file modification time (st_mtime). Switched
  to parsing the date out of each filename instead -- every file this
  pipeline touches already has one embedded
  (2026-07-26-scan_ssh-...csv, asset_exposure_20260726.csv,
  pipeline_2026-07-26.log) -- so retention is now tied to what date
  the DATA is for, not incidentally to when the file happened to be
  last written/touched. Falls back to mtime only for the rare file
  that doesn't match any known naming pattern, so nothing is silently
  skipped forever just because it doesn't parse.

RUN
  Called automatically as the last step of run_pipeline.py. Safe to
  also run manually / via its own cron entry -- it only ever removes
  files already past retention, regardless of what else has run.
============================================================
"""

import os
import re
import time
from datetime import datetime, timedelta
from pathlib import Path

REPORTS_ROOT = Path("/opt/shadowserver/reports")
EVENTSTORE_OUTPUT_DIR = Path("/opt/shadowserver/eventstore_uploads")
LOG_DIR = Path("/opt/shadowserver/logs")

REPORTS_RETENTION_DAYS = 7
EVENTSTORE_OUTPUT_RETENTION_DAYS = 7
LOG_RETENTION_DAYS = 30

# 2026-07-26-scan_ssh-11993-png_dataco-asn.csv
RAW_REPORT_DATE_RE = re.compile(r"^(\d{4}-\d{2}-\d{2})-")
# ioc_blocklist_20260726.csv / asset_exposure_20260726.csv / compromised_assets_20260726.csv
CONSOLIDATED_DATE_RE = re.compile(r"_(\d{8})\.csv$")
# pipeline_2026-07-26.log
LOG_DATE_RE = re.compile(r"_(\d{4}-\d{2}-\d{2})\.log$")


def _parse_date(text, fmt):
    try:
        return datetime.strptime(text, fmt)
    except ValueError:
        return None


def file_date(path: Path):
    """Best-effort: pull the date out of the filename. None if no
    known pattern matches -- caller falls back to mtime in that case."""
    name = path.name

    m = RAW_REPORT_DATE_RE.match(name)
    if m:
        d = _parse_date(m.group(1), "%Y-%m-%d")
        if d:
            return d

    m = CONSOLIDATED_DATE_RE.search(name)
    if m:
        d = _parse_date(m.group(1), "%Y%m%d")
        if d:
            return d

    m = LOG_DATE_RE.search(name)
    if m:
        d = _parse_date(m.group(1), "%Y-%m-%d")
        if d:
            return d

    return None


def purge(root: Path, pattern: str, retention_days: int, label: str):
    if not root.exists():
        print(f"  {label}: {root} does not exist, skipping")
        return

    cutoff = datetime.utcnow() - timedelta(days=retention_days)
    removed = 0
    fell_back_to_mtime = 0

    for path in root.rglob(pattern):
        d = file_date(path)
        if d is not None:
            is_old = d < cutoff
        else:
            # No parseable date in the filename -- fall back to mtime
            # rather than silently keeping the file forever.
            fell_back_to_mtime += 1
            is_old = path.stat().st_mtime < cutoff.timestamp()

        if is_old:
            path.unlink()
            removed += 1

    print(f"  {label}: removed {removed} file(s) older than {retention_days} days"
          + (f" ({fell_back_to_mtime} used mtime fallback, no parseable date)"
             if fell_back_to_mtime else ""))


def cleanup_empty_dirs(root: Path):
    if not root.exists():
        return
    for dirpath, _dirnames, _filenames in os.walk(root, topdown=False):
        d = Path(dirpath)
        if d == root:
            continue
        if d.is_dir() and not any(d.iterdir()):
            d.rmdir()


def main():
    print("cleaning raw Shadowserver reports...")
    purge(REPORTS_ROOT, "*.csv", REPORTS_RETENTION_DAYS, "reports/")
    cleanup_empty_dirs(REPORTS_ROOT)

    print("cleaning consolidated eventstore CSVs...")
    purge(EVENTSTORE_OUTPUT_DIR, "*.csv", EVENTSTORE_OUTPUT_RETENTION_DAYS, "eventstore_uploads/")

    print("cleaning pipeline logs...")
    purge(LOG_DIR, "*.log", LOG_RETENTION_DAYS, "logs/")

    print("done.")


if __name__ == "__main__":
    main()
