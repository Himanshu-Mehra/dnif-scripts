#!/usr/bin/env python3
"""
diff_compromised_website.py
============================================================
Handles compromised_website the way its actual shape calls for:
state-shaped data (same 14-column core as scan_*/device_id -- ip,
port, tag, asn, geo... plus application/url/family), not an event.

TWO THINGS HAPPEN, BOTH LOCAL BEFORE ANYTHING TOUCHES THE NETWORK:

  1. The full daily snapshot is pushed to a `compromised_assets`
     eventstore (delete-then-upload, same as ioc_blocklist and
     asset_exposure) -- this is called from consolidate_eventstore.py,
     not here.

  2. THIS script computes, entirely on this host, which of today's
     compromised_website rows are genuinely NEW -- i.e. an
     ip/port/application/url/family combination never seen in a
     previous run -- against a local state file. Only that small
     diffed set is what gets sent to the DNIF stream as a real event
     ("this asset was newly flagged compromised"). Everything else
     (the full row set, the comparison itself, the decision of what
     counts as new) happens here on disk; the network call at the end
     only ever carries the final, already-decided rows -- nothing
     resembling "send everything and let the SIEM figure out what's
     new" happens.

STATE FILE
  /opt/shadowserver/state/compromised_known_keys.json
  A JSON list of identity keys ever seen. It only grows -- so "new"
  here means "never flagged before", not "different from yesterday
  specifically". A host that's been compromised for a week doesn't
  re-alert every day; if it drops off the list and comes back later
  with the SAME identity fields, it also won't re-alert (rare edge
  case worth knowing about, not fixing preemptively -- tell me if you
  want re-appearance to count as new too).

  The state file is only updated AFTER a successful send. If the send
  fails, the new keys are NOT recorded as known, so the next run will
  correctly try to send them again instead of silently losing them.

IDENTITY KEY
  ip | port | application | url | family | detected_since
  Chosen from the fields most likely to distinguish two genuinely
  different compromise records. If Shadowserver ever sends rows with
  all of these blank, they'll collide into one key -- unlikely given
  the real data inspected, but flagging the assumption rather than
  hiding it.

RUN (called from consolidate_eventstore.py, or standalone for testing)
  /usr/bin/python3 /opt/shadowserver/diff_compromised_website.py [YYYY-MM-DD]
============================================================
"""

import csv
import json
import os
import re
import sys
from datetime import datetime
from pathlib import Path

from stream_forward import send_rows_to_siem

REPORTS_ROOT = Path("/opt/shadowserver/reports")
STATE_DIR = Path("/opt/shadowserver/state")
STATE_FILE = STATE_DIR / "compromised_known_keys.json"

SIEM_HOST = os.environ.get("DNIF_SIEM_HOST", "127.0.0.1")  # CONFIRM: real DNIF ingest host
SIEM_PORT = int(os.environ.get("DNIF_SIEM_PORT", "515"))

IDENTITY_FIELDS = ["ip", "port", "application", "url", "family", "detected_since"]

FNAME_RE = re.compile(r"^\d{4}-\d{2}-\d{2}-(?P<type>[a-z0-9_]+)-\d+-.+\.csv$")


def report_date_dir(date: datetime) -> Path:
    return REPORTS_ROOT / f"{date.year:04d}" / f"{date.month:02d}" / f"{date.day:02d}"


def find_compromised_website_file(date_dir: Path) -> Path | None:
    if not date_dir.exists():
        return None
    for f in sorted(date_dir.glob("*.csv")):
        m = FNAME_RE.match(f.name)
        if m and m.group("type") == "compromised_website":
            return f
    return None


def row_key(row: dict) -> str:
    return "|".join(row.get(f, "") for f in IDENTITY_FIELDS)


def load_known_keys() -> set:
    if not STATE_FILE.exists():
        return set()
    with open(STATE_FILE) as f:
        return set(json.load(f))


def save_known_keys(keys: set):
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    with open(STATE_FILE, "w") as f:
        json.dump(sorted(keys), f)


def find_new_rows(csv_path: Path, known_keys: set):
    """
    All computation happens here, locally, against the file already on
    disk and the local state file -- nothing about this step involves
    the network. Returns (new_rows, new_keys, total_row_count).
    """
    with open(csv_path, newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))

    new_rows = []
    new_keys = set()
    for row in rows:
        key = row_key(row)
        if key not in known_keys:
            new_rows.append(row)
            new_keys.add(key)

    return new_rows, new_keys, len(rows)


def run(date: datetime = None):
    date = date or datetime.utcnow()
    date_dir = report_date_dir(date)

    csv_path = find_compromised_website_file(date_dir)
    if not csv_path:
        print(f"  no compromised_website file for {date:%Y-%m-%d}, nothing to diff")
        return

    known_keys = load_known_keys()
    new_rows, new_keys, total = find_new_rows(csv_path, known_keys)

    print(f"  {csv_path.name}: {total} total rows, {len(new_rows)} new "
          f"(never seen before), {total - len(new_rows)} already known")

    if not new_rows:
        return

    try:
        sent = send_rows_to_siem(SIEM_HOST, SIEM_PORT, new_rows, "compromised_website_new")
    except OSError as e:
        print(f"  FAILED to send {len(new_rows)} new row(s) ({e}) -- "
              f"state NOT updated, will retry next run")
        return

    if sent != len(new_rows):
        print(f"  sent {sent}/{len(new_rows)} new rows -- state NOT updated, will retry next run")
        return

    # Only mark these as "known" now that delivery is confirmed.
    save_known_keys(known_keys | new_keys)
    print(f"  sent {sent} new row(s) to SIEM, state file updated")


if __name__ == "__main__":
    run_date = None
    if len(sys.argv) > 1:
        run_date = datetime.strptime(sys.argv[1], "%Y-%m-%d")
    run(run_date)
