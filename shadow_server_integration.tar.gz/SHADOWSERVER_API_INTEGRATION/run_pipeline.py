#!/usr/bin/env python3
"""
run_pipeline.py
============================================================
ONE script, ONE cron entry, runs the whole daily chain in order and
stops if a required step fails, instead of letting cron fire five
independent jobs that don't know about each other's success/failure.

CHAIN (each step only runs if the previous required one succeeded)
  1. report-manager.py            pulls yesterday's CSVs
  2. consolidate_eventstore_v3.py builds + uploads the 3 eventstores,
                                   AND internally runs the new-
                                   compromised-asset diff/alert step
                                   (diff_compromised_website.py is
                                   NOT a separate cron job -- this
                                   calls it directly)
  3. forward_stream_csv.py        forwards the 3 sinkhole event files
  4. cleanup_reports.py           ALWAYS runs, even if 1-3 failed --
                                   it only removes files already past
                                   retention, so it's safe regardless,
                                   and skipping it on a bad day would
                                   just compound the disk growth
                                   problem it exists to prevent

DATE HANDLING
  report-manager.py pulls "yesterday" relative to whenever it runs.
  Every downstream step is given that SAME date explicitly -- nothing
  in this chain defaults to "today", which would look for a folder
  that doesn't exist yet on the day it runs.

LOGGING
  One log file per run: logs/pipeline_<YYYY-MM-DD>.log (the report
  date, not today's date, so a log is easy to find by the data it
  covers). Also mirrored to stdout for cron's own mail-on-output
  behavior if you have that configured.

LOCKING
  A simple lock file (run.lock) prevents two runs overlapping if a
  previous day's run is still going (e.g. Shadowserver was slow) when
  today's cron fires. A lock older than STALE_LOCK_HOURS is treated
  as abandoned (crashed run) and cleared automatically rather than
  blocking forever.

BOOKMARK
  On full success, state/last_success_date.txt is updated with the
  report date just completed -- cheap way to check "did yesterday's
  run actually finish" without reading logs.

CRON -- replace the 7 separate entries with this ONE line
  0 12 * * * /usr/bin/python3 /opt/shadowserver/run_pipeline.py >> /opt/shadowserver/logs/cron.log 2>&1

CONFIRM BEFORE ENABLING
  REPORT_MANAGER_CMD now uses the real invocation (report-manager.py
  config.ini [days]). One assumption baked in: passing "1" as the
  days argument pulls exactly yesterday's report, matching
  report_date computed in main(). You ran it manually with no days
  arg -- if its default behavior differs from "1", or "days" doesn't
  mean "how many past days to pull", tell me and I'll fix the
  argument and the date math together so they can't drift apart.
============================================================
"""

import os
import subprocess
import sys
import time
from datetime import datetime, timedelta
from pathlib import Path

BASE_DIR = Path("/opt/shadowserver")
LOG_DIR = BASE_DIR / "logs"
STATE_DIR = BASE_DIR / "state"
LOCK_FILE = BASE_DIR / "run.lock"
STALE_LOCK_HOURS = 4

LOG_DIR.mkdir(parents=True, exist_ok=True)
STATE_DIR.mkdir(parents=True, exist_ok=True)

# report-manager.py usage: report-manager.py /path/to/config.ini [ days ]
CONFIG_INI = BASE_DIR / "config.ini"
REPORT_MANAGER_CMD = [
    sys.executable, str(BASE_DIR / "report-manager.py"),
    str(CONFIG_INI),
    "1",  # CONFIRM: assuming "days" means "pull the last N days" and that
          # passing 1 explicitly pulls exactly yesterday's report, matching
          # report_date below, rather than relying on whatever it defaults
          # to when omitted (you ran it with no days arg manually). If
          # "days" means something else (an offset, a lookback window that
          # doesn't map 1:1 to "yesterday"), tell me and I'll adjust this
          # and the date math in main() together so they stay in sync.
]

PY = sys.executable


def log_line(log_file, msg):
    ts = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line)
    with open(log_file, "a") as f:
        f.write(line + "\n")


def acquire_lock(log_file):
    if LOCK_FILE.exists():
        age_hours = (time.time() - LOCK_FILE.stat().st_mtime) / 3600
        if age_hours < STALE_LOCK_HOURS:
            log_line(log_file, f"lock file present and only {age_hours:.1f}h old -- "
                                f"another run appears to be in progress, exiting")
            sys.exit(1)
        log_line(log_file, f"lock file is {age_hours:.1f}h old (> {STALE_LOCK_HOURS}h) -- "
                            f"treating as abandoned from a crashed run, clearing it")
    LOCK_FILE.write_text(str(os.getpid()))


def release_lock():
    LOCK_FILE.unlink(missing_ok=True)


def run_step(name, cmd, log_file) -> bool:
    log_line(log_file, f"STEP START: {name} -- {' '.join(cmd)}")
    result = subprocess.run(cmd, cwd=BASE_DIR, capture_output=True, text=True)
    for line in (result.stdout or "").splitlines():
        log_line(log_file, f"  {line}")
    for line in (result.stderr or "").splitlines():
        log_line(log_file, f"  [stderr] {line}")

    if result.returncode == 0:
        log_line(log_file, f"STEP OK: {name}")
        return True
    log_line(log_file, f"STEP FAILED: {name} (exit code {result.returncode})")
    return False


def main():
    report_date = datetime.utcnow() - timedelta(days=1)
    date_str = report_date.strftime("%Y-%m-%d")
    log_file = LOG_DIR / f"pipeline_{date_str}.log"

    acquire_lock(log_file)
    try:
        log_line(log_file, f"=== pipeline run starting for report date {date_str} ===")

        ok = run_step("report-manager.py", REPORT_MANAGER_CMD, log_file)

        if ok:
            ok = run_step(
                "consolidate_eventstore_v3.py",
                [PY, str(BASE_DIR / "consolidate_eventstore_v3.py"), date_str],
                log_file,
            )

        if ok:
            ok = run_step(
                "forward_stream_csv.py",
                [PY, str(BASE_DIR / "forward_stream_csv.py"), date_str],
                log_file,
            )

        # Cleanup always runs, chain success or not -- it only removes
        # files already past their retention window, so it's safe
        # regardless, and skipping it on a bad day just makes the
        # disk-growth problem worse.
        run_step(
            "cleanup_reports.py",
            [PY, str(BASE_DIR / "cleanup_reports.py")],
            log_file,
        )

        if ok:
            (STATE_DIR / "last_success_date.txt").write_text(date_str)
            log_line(log_file, f"=== pipeline run COMPLETE for {date_str} ===")
        else:
            log_line(log_file, f"=== pipeline run FAILED for {date_str} -- "
                                f"see STEP FAILED line above ===")
            sys.exit(1)
    finally:
        release_lock()


if __name__ == "__main__":
    main()
